﻿~~~
Author:	Devin Fink
Partner: None
Start Date: 02/09/23
Course: CS 3500, University of Utah School of Computing
GitHub ID: deimos-5
Repo: https://github.com/uofu-cs3500-spring23/spreadsheet-deimos-5.git
Commit Date: 02/09/23
Project: SpreadsheetTests
Copyright: CS 3500 and Devin Fink - This work may not be copied for academic coursework
~~~
# Overview of Project Functionality
This is the testing document for the Spreadsheet Project. I got to 100% code coverage

# Comments to Evaluators:
N/A.

# Assignment Specific
I spent about 5 hours on this assignment. Testing took approximately 2 of those hours.

# Consulted Peers:
- Annabelle Warner

# References: 
N/A