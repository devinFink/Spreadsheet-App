﻿~~~
Author:	Devin Fink
Partner: None
Start Date: 01/29/23
Course: CS 3500, University of Utah School of Computing
GitHub ID: deimos-5
Repo: https://github.com/uofu-cs3500-spring23/spreadsheet-deimos-5.git
Commit Date: 02/02/23
Project: Formula
Copyright: CS 3500 and Devin Fink - This work may not be copied for academic coursework
~~~
# Overview of Project Functionality
This projcet holds an object to represent variables in the spreadsheet. These formulas
are immutable, checked for syntax in an efficient manner, and can be evaluated using 
multiple different types of variables.
This will be used in future projects to provide functionality to the spreadsheet cells

# Comments to Evaluators:
This project was extremely confusing for me to understand. The instructions seemed 
very convoluted, with a lot of extrenous information that hindered my progress. I believe
the project I ended up with is an efficient solution and works well, however it was a pain getting here.

# Assignment Specific
I predicted to spend 10 hours on this assignment. I spent about 12 hours total. About 3 of those hours were simply 
contemplating the instructions and setting up the files, because I was so confused. After that I spent about 
2 hours building and testing the constructor and syntax checker, and the remainder making sure evaluate works
and testing (very) thouroughly. 

# Consulted Peers:
- Annabelle Warner

# References: 

	1. Microsoft Documentation - https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/reference-types?f1url=%3FappId%3DDev16IDEF1%26l%3DEN-US%26k%3Dk(string_CSharpKeyword)%3Bk(DevLang-csharp)%26rd%3Dtrue
	2. Stack Overflow - https://stackoverflow.com/
	3. Wikipedia (For Regexes) - https://en.wikipedia.org/wiki/Regular_expression