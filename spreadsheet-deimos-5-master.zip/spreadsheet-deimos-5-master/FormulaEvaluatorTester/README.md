﻿~~~
Author:	Devin Fink
Partner: None
Start Date: 1/17/22
Course: CS 3500, University of Utah School of Computing
GitHub ID: deimos-5
Repo: https://github.com/uofu-cs3500-spring23/spreadsheet-deimos-5.git
Commit Date: 1-19-22 10:10PM
Project: Formula Evaluator
Copyright: CS 3500 and Devin Fink - This work may not be copied for academic coursework
~~~
# Overview of Project Functionality
This is the tester for the formula evaluator portion of the spreadsheet
All of the following info is copied from tht README.

# Comments to Evaluators:
The README document did not say the project functionality section
was needed, but I felt like I should add it just in case to match
closer to the format of the solution readme.
There are no helper methods, although the project 
may have been much more streamlined with some. As of
now the code seems very "If-Statement" heavy, but it does the job.

# Assignment Specific
I predicted to spend 5 hours on this assignment. I spent about 8 hours total, with 2 being the beginning stages, about 3 on the
actual algorithm writing, and 3 more being bugfixing and test writing

# Consulted Peers:
- Annabelle Warner

# References: 

	1. Microsoft Documentation - https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/reference-types?f1url=%3FappId%3DDev16IDEF1%26l%3DEN-US%26k%3Dk(string_CSharpKeyword)%3Bk(DevLang-csharp)%26rd%3Dtrue
	2. Stack Overflow - https://stackoverflow.com/
	3. Wikipedia (For Regexes) - https://en.wikipedia.org/wiki/Regular_expression