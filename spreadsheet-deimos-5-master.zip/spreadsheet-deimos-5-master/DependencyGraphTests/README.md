﻿~~~
Author:	Devin Fink
Partner: None
Start Date: 1/26/22
Course: CS 3500, University of Utah School of Computing
GitHub ID: deimos-5
Repo: https://github.com/uofu-cs3500-spring23/spreadsheet-deimos-5.git
Commit Date: 1-29-22 10:30PM
Project: DependencyGraph
Copyright: CS 3500 and Devin Fink - This work may not be copied for academic coursework
~~~
# Overview of Project Functionality
Thisis the testing code for my DependencyGraph project

# Comments to Evaluators:
This is testing code. It covers all my code. Hopefully I did it well, 
I struggled to come up with obscure edgecases.

# Assignment Specific
I spent about 2 hours on this testing portion, not including the 2 hour visual studio struggle.

# Consulted Peers:
- Annabelle Warner

# References: 

	1. Microsoft Documentation - https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/reference-types?f1url=%3FappId%3DDev16IDEF1%26l%3DEN-US%26k%3Dk(string_CSharpKeyword)%3Bk(DevLang-csharp)%26rd%3Dtrue